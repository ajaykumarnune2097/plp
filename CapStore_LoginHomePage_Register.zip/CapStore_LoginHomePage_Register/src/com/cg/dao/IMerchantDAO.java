package com.cg.dao;

import java.util.List;

import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.SoldItems;

public interface IMerchantDAO {

		Merchant isMerchant(String userName, String userPassword);
		String getMerchantPassword(String userName);
		void plp();
		public void viewInventory();
		public void addProducts();
		public void removeProduct();
		public void addDiscount();
		public void removeDiscount();
		public void checkOrders();
		public void promos();
		List<Inventory> loadAll(int id);
		public boolean removeInventory(int inventory);
		Inventory findinventory(int inventoryId);
		Inventory addinventory(Inventory inventories);
		Merchant findMerchant(int merchantId);
		void updateInventory(Inventory inventory);
		void updateInventoryImage(Inventory inventory);
		Merchant showDetails(int id);
		List<Inventory> getAllInventory();
		List<SoldItems> getAllInventoryOfMerchant(int merchantId);
		void updateStatus(int merchantId, SoldItems soldItems, String string);
		void setRating(String rate, String soldId);

}
