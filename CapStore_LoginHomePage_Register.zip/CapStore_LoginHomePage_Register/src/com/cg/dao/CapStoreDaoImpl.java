package com.cg.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Coupons;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.SoldItems;

@Repository
public class CapStoreDaoImpl implements ICapStoreDao {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public boolean add(int customerId,int inventoryId) {
		
		//int inventoryId = 0;
		
		Customer cust=entityManager.find(Customer.class, customerId);
		Inventory inventory=entityManager.find(Inventory.class, inventoryId);
		if(cust.getCart().contains(inventory))
		{
			return false;
		}
		else
		{
			cust.getCart().add(inventory);
			return true;
		}
		
		
	}

	@Override
	public void remove(int inventoryId,int customerId) {
		//int customerId=7;
		
		Customer cust=entityManager.find(Customer.class, customerId );
		Inventory inventory=entityManager.find(Inventory.class, inventoryId);
		cust.getCart().remove(inventory);
		
	}

	@Override
	public void tableCreation() {
		Merchant merchant=new Merchant("merchant@gmail.com","mpassword","merchantname","address",5.0,500.0);
		merchant.setMoney(0.00);
		Inventory inventory=new Inventory("inventoryName",5,450.0,"inventoryType",50.0);
		Inventory inventory1=new Inventory("Name",2,300.0,"type2",10.0);
		inventory.setFileName("download.jpg");
		inventory1.setFileName("laptop.jpg");
		Coupons coupons=new Coupons("asfa", new Date(), 12.00);
		Coupons coupons1=new Coupons("asfasg", new Date(), 1.00);
		Coupons coupons2=new Coupons("asawewfasg", new Date(), 120.00);
		Admin admin=new Admin("admin", "admin@gmail.com", "aeolr68", 0.00);
		ArrayList<Inventory> invent=new ArrayList<>();
		invent.add(inventory);
		invent.add(inventory1);
		Customer customer=new Customer("customer@gmail.com","jpjq57","customerName","address");
		Customer customer2=new Customer("sdffaefr@gmail.com","cpassword2","customerName","address");
		customer.setCart(inventory);
		customer.setCart(inventory1);
		customer.setWishList(inventory);
		inventory.setMerchant(merchant);
		inventory1.setMerchant(merchant);
		customer.setCoupons(coupons);
		customer.setCoupons(coupons1);
		customer2.setCoupons(coupons2);
		entityManager.persist(admin);
		entityManager.persist(coupons2);
		entityManager.persist(coupons);
		entityManager.persist(coupons1);
		entityManager.persist(merchant);
		entityManager.persist(inventory);
		entityManager.persist(inventory1);
		entityManager.persist(customer);
		entityManager.persist(customer2);		
		
		
	}

	@Override
	public List<Inventory> fetchCart(int customerId) {
		Query cart=entityManager.createQuery("select cust.cart from Customer cust where cust.customerId="+customerId,Collection.class);
		return cart.getResultList();
		
	}

	@Override
	public boolean checkAvailability(int customerId) {
		 int flag=0;
		/*
		 * int flag=0; int i=0; Customer cust=entityManager.find(Customer.class,
		 * customerId); //Inventory inventory=entityManager.find(Inventory.class,
		 * inventoryId); List<Inventory> cart=cust.getCart(); List<Inventory>
		 * invent=entityManager.createQuery("select i from inventory i",Inventory.class)
		 * .getResultList();
		 * 
		 * for(Inventory cartItems:cart) { for(Inventory inventoryItems: invent) {
		 * if(cartItems.getInventoryId()==inventoryItems.getInventoryId()) {
		 * if(Integer.parseInt(quantity[i])<=inventoryItems.getQuantity()) { flag++;
		 * i++; } } } } if(cart.size()==flag) return true; else return false;
		 */
		Query query=entityManager.createQuery("select c.cart from Customer c",Collection.class);
		List<Inventory> inventories=query.getResultList();
		for(Inventory inventory:inventories) {
			if(inventory.getQuantity()<1) {
				flag=1;
				break;
			}
		}
		if(flag==0)
			return true;
		else
			return false;
}

	@Override
	public int totalAmount(int customerId) {
		double amount=0;
		Customer cust=entityManager.find(Customer.class, customerId);
		List<Inventory> cart=cust.getCart();
		
		for(int i=0;i<cart.size();i++)
		{
			amount=amount+cart.get(i).getPrice();
		}
		
		return (int)amount;
	}

	@Override
	public int totalDiscount(int customerId) {
		double discount=0;
		Customer cust=entityManager.find(Customer.class, customerId);
		List<Inventory> cart=cust.getCart();for(int i=0;i<cart.size();i++)
		{
			discount=discount+cart.get(i).getDiscount();
		}
		
		return (int)discount;
	}

	@Override
	public List<String> getCoupons(int customerId) {
		Query coupon= entityManager.createQuery("select s.coupons from Customer s where s.customerId="+customerId,Collection.class);
		//System.out.println(coupon.getResultList());
		List<Coupons> coupons=coupon.getResultList();
		List<String> couponsNumber=new ArrayList<String>();
		for(Coupons coupon2:coupons) {
			couponsNumber.add(coupon2.getCouponNumber());
			System.out.println(coupon2);
		}
		return couponsNumber;	
	}

	@Override
	public Double getCouponDiscount(String couponId) {
		Query coupon=entityManager.createQuery("select c from Coupons c where c.couponNumber=:cNumber",Coupons.class);
		coupon.setParameter("cNumber", couponId);
		List<Coupons>coupons=coupon.getResultList();
		
		return coupons.get(0).getDiscount();
	}

	@Override
	public Customer getCustomer(int customerId) {
		// TODO Auto-generated method stub
		return entityManager.find(Customer.class, customerId);
	}

	@Override
	public void updateMoney(List<Inventory> list) {
		for(Inventory inventory:list)
		{
			inventory.getMerchant().setMoney(inventory.getMerchant().getMoney()+inventory.getPrice()-inventory.getDiscount());
			inventory.setQuantity(inventory.getQuantity()-1);
		}
		
	}

	@Override
	public void addSoldItems(int customerId, int inventoryId) {
		// TODO Auto-generated method stub
		Customer cust=entityManager.find(Customer.class, customerId);
		Inventory inventory=entityManager.find(Inventory.class, inventoryId);
		Date exceptedDate=new Date();
		exceptedDate.setMonth(exceptedDate.getMonth()+1);
		SoldItems items=new SoldItems(cust, inventory,"", new Date(), "orderPlaced", exceptedDate, 1);
		entityManager.persist(items);
	}

	@Override
	public void deleteCoupon(String couponId) {
		// TODO Auto-generated method stub
		Query coupon=entityManager.createQuery("select c from Coupons c where c.couponNumber=:cNumber",Coupons.class);
		coupon.setParameter("cNumber", couponId);
		List<Coupons>coupons=coupon.getResultList();
		entityManager.remove(coupons.get(0));
	}
	
	
	

}
