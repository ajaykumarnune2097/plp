package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.dao.ICapStoreDao;
import com.cg.entities.Coupons;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
@Service
@Transactional
public class CapStoreServiceImpl implements ICapStoreService {

	@Autowired
	ICapStoreDao iCapStoreDao;
	
	@Override
	public boolean add(int customerId,int inventoryId) {
		// TODO Auto-generated method stub
		return iCapStoreDao.add(customerId,inventoryId); 
	}

	@Override
	public void remove(int inventoryId,int customerId) {
		
		iCapStoreDao.remove(inventoryId,customerId);
	}

	@Override
	public void tableCreation() {
		iCapStoreDao.tableCreation();
		
	}

	@Override
	public List<Inventory> fetchCart(int customerId) {
		
		return iCapStoreDao.fetchCart(customerId);
	}

	@Override
	public boolean checkAvailability(int customerId) {
		
		return iCapStoreDao.checkAvailability(customerId);
	}

	@Override
	public int totalAmount(int customerId) {
		
		return iCapStoreDao.totalAmount(customerId);
	}

	@Override
	public int totalDiscount(int customerId) {
		
		return iCapStoreDao.totalDiscount(customerId);
	}

	@Override
	public List<String> getCoupons(int customerId) {
		// TODO Auto-generated method stub
		return iCapStoreDao.getCoupons(customerId);
	}

	@Override
	public Double getCouponDiscount(String couponId) {
		// TODO Auto-generated method stub
		return iCapStoreDao.getCouponDiscount(couponId);
	}

	@Override
	public Customer getCustomer(int customerId) {
		// TODO Auto-generated method stub
		return iCapStoreDao.getCustomer(customerId);
	}

	@Override
	public void updateMoney(List<Inventory> list) {
		// TODO Auto-generated method stub
		iCapStoreDao.updateMoney(list);
	}

	@Override
	public void addSoldItems(int customerId, int inventoryId) {
		// TODO Auto-generated method stub
		iCapStoreDao.addSoldItems(customerId,inventoryId);
	}

	@Override
	public void deleteCoupon(String couponId) {
		// TODO Auto-generated method stub
		iCapStoreDao.deleteCoupon(couponId);
	}

}
