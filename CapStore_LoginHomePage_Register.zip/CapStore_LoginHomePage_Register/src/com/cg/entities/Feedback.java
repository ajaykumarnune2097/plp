package com.cg.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Feedback {

	@Id
	@GeneratedValue
	private int feedbackId;
	private String feedback;
	private int acceptedByAdmin;
	@OneToOne
	private Customer customer;
	@OneToOne
	private Merchant merchant;
	
	public int getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public int getAcceptedByAdmin() {
		return acceptedByAdmin;
	}
	public void setAcceptedByAdmin(int acceptedByAdmin) {
		this.acceptedByAdmin = acceptedByAdmin;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Merchant getMerchant() {
		return merchant;
	}
	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}
	public Feedback(String feedback, int acceptedByAdmin, Customer customer, Merchant merchant) {
		super();
		this.feedback = feedback;
		this.acceptedByAdmin = acceptedByAdmin;
		this.customer = customer;
		this.merchant = merchant;
	}
	public Feedback() {
		super();
	}
	
	
	
}
