package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Coupons;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.service.ICapStoreService;


@Controller
public class ControllerClass {

	@Autowired
	ICapStoreService iCapStoreService;
	
	@PersistenceContext
	EntityManager entityManager;
	
	List<String> quantity;
	
	
	/*@RequestMapping("/index")
	public String page()
	{
		iCapStoreService.tableCreation();
		return "index";
	}*/
	
	
	@RequestMapping("/addToCart")
	public String add(Model model,@RequestParam("") String inventoryId,HttpSession session)
	{
		int customerId=0;
		quantity=new ArrayList<String>();
		quantity.add("1");
		quantity.add("2");
		quantity.add("3");
		List<Inventory> list=iCapStoreService.fetchCart(customerId);
		boolean add=iCapStoreService.add(customerId,Integer.parseInt(inventoryId));
		if(add)
		{
			model.addAttribute("quantity",quantity);
			model.addAttribute("cartList",list);
			return "cart";
		}
		else
		{
			model.addAttribute("quantity",quantity);
			model.addAttribute("cartList",list);
			return "cart";
		}
		
		
	}
	
	@RequestMapping("/removeFromCart")
	public String remove(Model model,@RequestParam("name")String inventoryId,HttpSession session)
	{
		int customerId=(int)session.getAttribute("userId");
		iCapStoreService.remove(Integer.parseInt(inventoryId),customerId);
		//List<Inventory> list=iCapStoreService.fetchCart();
		//model.addAttribute("cartList",list);
		return "redirect:customerCart.html";
	}
	
	@RequestMapping("/customerCart")
	public String display(Model model,HttpSession session)
	{
		int customerId=(int)session.getAttribute("userId");
		List<Inventory> list=iCapStoreService.fetchCart(customerId);
		int amount=iCapStoreService.totalAmount(customerId);
		int discount=iCapStoreService.totalDiscount(customerId);
		model.addAttribute("amount",amount);
		model.addAttribute("discount",discount);
		model.addAttribute("cartList",list);
		model.addAttribute("finalAmount",amount-discount);
		if(list.isEmpty())
			model.addAttribute("buy",1);
		return "cart";
	}
	
	/*@RequestMapping("/validate")
	public String checkAvailability(HttpServletRequest request)
	{
		//int customerId=0;
		//boolean check=iCapStoreService.checkAvailability(customerId);
		//if(check)
		

		 String a[]= request.getParameterValues("quantity"); 
		// System.out.println(a.length);
			return "success";
		//else
			//return "cart";
			
			// String a[]= request.getParameterValues("quantity"); 
				
	}*/

	/*@RequestMapping(value="/validate")
	public String getInvoice(Model model)
	{
		int customerId=3;
		List<Inventory> list=iCapStoreService.fetchCart();
		int amount=iCapStoreService.totalAmount(customerId);
		int discount=iCapStoreService.totalDiscount(customerId);
		model.addAttribute("amount",amount);
		model.addAttribute("discount",discount);
		model.addAttribute("cartList",list);
		model.addAttribute("finalAmount",amount-discount);
		
		return "invoice";
		
	}*/
	@RequestMapping(value="/validate")
	public String getInvoice(Model model,HttpSession session)
	{
		int customerId=(int)session.getAttribute("userId");
		List<Inventory> list=iCapStoreService.fetchCart(customerId);
		//iCapStoreService.checkAvailability(customerId);----------required
		int amount=iCapStoreService.totalAmount(customerId);
		int discount=iCapStoreService.totalDiscount(customerId);
		model.addAttribute("amount",amount);
		model.addAttribute("discount",discount);
		model.addAttribute("cartList",list);
		model.addAttribute("finalAmount",amount-discount);
		List<String> couponsNumber=iCapStoreService.getCoupons(customerId);
		model.addAttribute("coupons",couponsNumber);
		
		return "applyCoupons";
		
	}
	
	@RequestMapping("/bankdetails")
	public String bankdetails(Model model,@RequestParam("couponId")String couponId,HttpSession session) {
		int customerId=(int)session.getAttribute("userId");
		List<Inventory> list=iCapStoreService.fetchCart(customerId);
		int amount=iCapStoreService.totalAmount(customerId);
		int discount=iCapStoreService.totalDiscount(customerId);
		System.out.println(couponId);
		Double couponAmount=0.00;
		if(!couponId.equals("null")) {
		couponAmount=iCapStoreService.getCouponDiscount(couponId);
		}
		model.addAttribute("couponId", couponId);
		model.addAttribute("amount",amount);
		model.addAttribute("discount",discount);
		model.addAttribute("cartList",list);
		model.addAttribute("finalAmount",amount-discount-couponAmount);
		//List<String> couponsNumber=iCapStoreService.getCoupons(customerId);
		//model.addAttribute("coupons",couponsNumber);
		model.addAttribute("customerName", iCapStoreService.getCustomer(customerId).getCustomerName());
		return "payment";
		
	}
	
	@RequestMapping("/bought")
	public String bought(@RequestParam("money") String money,@RequestParam("card") String cardNumber,@RequestParam("couponId")String couponId,Model model,HttpSession session) {
		int customerId=(int)session.getAttribute("userId");
		List<Inventory> list=iCapStoreService.fetchCart(customerId);
		List<String> address=new ArrayList<String>();
		for(Inventory inventory:list) {
			iCapStoreService.addSoldItems(customerId,inventory.getInventoryId());
			address.add(inventory.getMerchant().getAddress());
			iCapStoreService.remove(inventory.getInventoryId(),customerId);
		}
		if(!couponId.equals("null")) {
		iCapStoreService.deleteCoupon(couponId);
		}
		iCapStoreService.updateMoney(list);
		Customer customer=iCapStoreService.getCustomer(customerId);
		model.addAttribute("toaddress",customer.getAddress());
		model.addAttribute("fromaddress",address);
		model.addAttribute("cartList",list);
		model.addAttribute("finalAmount",money);
		return "invoice";
	}
	
	
}
